/*
 * CS354: Operating Systems. 
 * Purdue University
 * Example that shows how to read one line with simple editing
 * using raw terminal.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <termios.h>

#define MAX_BUFFER_LINE 2048

// Buffer where line is stored
int line_length;;
char line_buffer[MAX_BUFFER_LINE];

// Simple history array
// This history does not change. 
// Yours have to be updated.
int history_index = 0;
int history_count = 0;

char *history[1024] = {}; 

int history_length = sizeof(history)/sizeof(char *);

void read_line_print_usage()
{
  char * usage = "\n"
    " ctrl-?       Print usage\n"
    " Backspace    Deletes last character\n"
    " up arrow     See last command in the history\n";

  write(1, usage, strlen(usage));
}

/* 
 * Input a line with some basic editing.
 */
extern char * read_line() 
{
  	struct termios orig_attr;
  	tcgetattr(0, &orig_attr);
  
  	// Set terminal in raw mode
  	tty_raw_mode();

  	line_length = 0;
  	int len = 0;
  	// Read one line until enter is typed
  	while (1) 
	{

    		// Read one character in raw mode.
    		char ch;
    		read(0, &ch, 1);

    		if (ch>=32 && ch != 127 && ch != 27) 
		{
      			// It is a printable character. 
      
      			if(len != line_length)
      			{
      				int currIndex = line_length - 1;
				for(currIndex = line_length-1; currIndex >= len; currIndex--)
				{
					char ch1 = line_buffer[currIndex];
					line_buffer[currIndex] = line_buffer[currIndex-1];
					line_buffer[currIndex+1] = ch1;
				}
    	
				line_buffer[len] = ch;
				int i;
				int endIndex = line_length - len;
				for (i = 0; i < endIndex; i++) 
				{
					char a = 27; 
					char b = 91; 
					char c = 67;
					write(1,&a,1); 
					write(1,&b,1); 
					write(1,&c,1);
				}

				i = 0;
				for (i =0; i < line_length; i++) 
				{
	  				ch = 8;
	  				write(1,&ch,1);
				}

				for (i =0; i < line_length; i++) 
				{
		  			ch = ' ';
		  			write(1,&ch,1);
				}
	
				for (i =0; i < line_length; i++) 
				{
		  			ch = 8;
		  			write(1,&ch,1);
				}	

				line_length++;
				write(1, line_buffer, line_length);

				for (i =0; i < line_length; i++) 
				{
		  			ch = 8;
		  			write(1,&ch,1);
				}	
				line_buffer[line_length] ='\0';
				len++;

				for (i = 0; i < len; i++) 
				{
					char a = 27; 
					char b = 91; 
					char c = 67;
					write(1,&a,1); 
					write(1,&b,1); 
					write(1,&c,1);
				}				
      			}
      			else
      			{
      				write(1,&ch,1);

      				if (line_length==MAX_BUFFER_LINE-2) break; 

      				line_buffer[line_length]=ch;
      				line_length++;
      				len++;
      			}
    		}
    		else if (ch==10) 
		{
      			// <Enter> was typed. Return line
      	
			line_buffer[line_length] = '\0';
			history[history_count] = strdup(line_buffer);
			history_count++;
			history_index = history_count;
	
      			// Print newline
     			write(1,&ch,1);

      			break;
    		}
    		else if (ch == 31) 
    		{
      			// ctrl-?
      			read_line_print_usage();
      			line_buffer[0]=0;
      			break;
    		}
    		else if (ch == 127 || ch == 8) 
    		{
      			// <backspace> was typed. Remove previous character read.
     			
			
			if (len == 0) {}
			else 
			{
				int index = len;
				for (; index < line_length; index++) 
				{
					char t = line_buffer[index];
					line_buffer[index] = line_buffer[index+1];
					line_buffer[index-1] = t;
				}

				int clearLine = line_length - len;
				for (index = 0; index < clearLine; index++) 
				{
					char a = 27; 
					char b = 91; 
					char c = 67;
					write(1,&a,1); 
					write(1,&b,1); 
					write(1,&c,1);
				}
			
				int i = 0;
				for (i =0; i < line_length; i++) 
				{
			  		ch = 8;
			  		write(1,&ch,1);
				}

				for (i =0; i < line_length; i++) 
				{
			  		ch = ' ';
			  		write(1,&ch,1);
				}

				for (i =0; i < line_length; i++) 
				{
			  		ch = 8;
			  		write(1,&ch,1);
				}	
			
				// echo line
				line_length--;
				write(1, line_buffer, line_length);
			
				for (i =0; i < line_length; i++) 
				{
			  		ch = 8;
			  		write(1,&ch,1);
				}	
				line_buffer[line_length] ='\0';
			
				len--;

				for (index = 0; index < len; index++) 
				{
					char a = 27; 
					char b = 91; 
					char c = 67;
					write(1,&a,1); 
					write(1,&b,1); 
					write(1,&c,1);
				}			
			}
		}
    		else if (ch==27) 
		{
      			// Escape sequence. Read two chars more
      			//
      			// HINT: Use the program "keyboard-example" to
      			// see the ascii code for the different chars typed.
      			//
      			char ch1; 
      			char ch2;
			read(0, &ch1, 1);
      			read(0, &ch2, 1);
      			if(ch1 == 91 && ch2 == 68)
      			{
     	 			if(len == 0);
	 			else
	 			{
					write(1,&ch,1);
					write(1,&ch1,1);
					write(1,&ch2,1);
					len--;
	 			}
      			}
      
      			if(ch1 == 91 && ch2 == 67)
      			{
      				if(len == line_length);
				else
				{
					write(1, &ch, 1);
					write(1, &ch1, 1);
					write(1, &ch2, 1);
					len++;
				}
      			}


      			if (ch1==91 && ch2==65) 
      			{
				// Up arrow. Print next line in history.
	
				if(history_index == 0);
				else
				{
					history_index--;
					// Erase old line
					// Print backspaces
					int i = 0;
					for (i =0; i < line_length; i++) 
					{
	  					ch = 8;
	  					write(1,&ch,1);
					}

					for (i =0; i < line_length; i++) 
					{
	  					ch = ' ';
	  					write(1,&ch,1);
					}

					for (i =0; i < line_length; i++) 
					{
	  					ch = 8;
	  					write(1,&ch,1);
					}	
					strcpy(line_buffer, history[history_index]);
					line_length = strlen(line_buffer);
					len = line_length;

					// echo line
					write(1, line_buffer, line_length);
      				}
     			}				  
     
     			if(ch1==91 && ch2==66)
     			{
     				//Down arrow
				
				if(history_index == history_count-1);
				else
				{
					history_index++;
					int i = 0;
					for(i = 0; i < line_length; i++)
					{
						ch = 8;
						write(1,&ch,1);
					}
		
					for(i = 0; i < line_length; i++)
					{
						ch = ' ';
						write(1,&ch,1);
					}
		
					for(i = 0; i < line_length; i++)
					{
						ch = 8;
						write(1,&ch,1);
					}
		
					strcpy(line_buffer, history[history_index]);
					line_length = strlen(line_buffer);
					len = line_length;
					write(1,line_buffer,line_length);
				}
     			}
    
    			if(ch1==79 && ch2==70)
    			{
    				int x = 0;
				int end = line_length - len;
				for(x = 0; x < end; x++)
				{
					char a = 27;
					char b = 91;
					char c = 67;

					write(1,&a,1);
					write(1,&b,1);
					write(1,&c,1);
				}
    				len = line_length;
    			}
    
  			if(ch1==79 && ch2==72)
    			{
				while(len > 0)
				{
					char a = 27;
					char b = 91;
					char c = 68;

					write(1, &a, 1);
					write(1, &b, 1);
					write(1, &c, 1);
					len--;
				}
    				len = 0;
    			}

			if(ch1 == 91 && ch2 == 51)
			{
				char ch3;
				read(0,&ch3,1);
				
				if(ch3==126)
				{
					if(len < 0);
					else
					{
						char end = line_buffer[len];
						if(end == '\0');
						else
						{
							int index = len+1;
							for(; index < line_length; index++)
							{
								char t = line_buffer[index];
								line_buffer[index] = line_buffer[index+1];
								line_buffer[index-1] = t;
							}

							int endIndex = line_length - len;
							for (index = 0; index < endIndex; index++) 
							{
								char a = 27; 
								char b = 91; 
								char c = 67;
								write(1,&a,1); 
								write(1,&b,1); 
								write(1,&c,1);
							}

							int i = 0;
							for (i =0; i < line_length; i++) 
							{
				  				ch = 8;
				  				write(1,&ch,1);
							}
							for (i =0; i < line_length; i++) 
							{
					  			ch = ' ';
					  			write(1,&ch,1);
							}
							for (i =0; i < line_length; i++) 
							{
					  			ch = 8;
					  			write(1,&ch,1);
							}	

							line_length--;
							write(1, line_buffer, line_length);
							for (i =0; i < line_length; i++) 
							{
					  			ch = 8;
					  			write(1,&ch,1);
							}	
							line_buffer[line_length] ='\0';

							for (i = 0; i < len; i++) 
							{
								char a = 27; 
								char b = 91; 
								char c = 67;
								write(1,&a,1); 
								write(1,&b,1); 
								write(1,&c,1);
							}
						}
					}
    				}
			}
		}

    		if(ch==1)
    		{
      			while(len > 0)
			{	
				char a = 27;
				char b = 91;
				char c = 68;

				write(1, &a, 1);
				write(1, &b, 1);
				write(1, &c, 1);
				len--;
			}
    			len = 0;
    		}
    
    		if(ch == 5)
    		{
       			int x = 0;
			int end = line_length - len;
			for(x = 0; x < end; x++)
			{
				char a = 27;
				char b = 91;
				char c = 67;

				write(1,&a,1);
				write(1,&b,1);
				write(1,&c,1);
			}
    			len = line_length;
    		}    
		
		if(ch == 4)
		{
			if(len < 0);
			else
			{
				char end = line_buffer[len];
				if(end == '\0');
				else
				{
					int index = len + 1;
					for(; index < line_length; index++)
					{
						char t = line_buffer[index];
						line_buffer[index] = line_buffer[index+1];
						line_buffer[index-1] = t;
					}
					
					int endIndex = line_length - len;
					for(index = 0; index < endIndex; index++)
					{
						char a = 27;
						char b = 91;
						char c = 67;
						write(1,&a,1);
						write(1,&b,1);
						write(1,&c,1);
					}
					
					int i;
					for(i = 0; i < line_length; i++)
					{
						char a = 8;
						write(1,&a,1);
					}
					
					for(i = 0; i < line_length; i++)
					{
						char a = ' ';
						write(1,&a,1);
					}
					
					for(i = 0; i < line_length; i++)
					{
						char a = 8;
						write(1,&a,1);
					}
					
					line_length--;
					write(1,line_buffer,line_length);

					for(i = 0; i < line_length; i++)
					{
						char a = 8;
						write(1,&a,1);
					}
					
					line_buffer[line_length] = '\0';
					
					for(index = 0; index < len; index++)
					{
						char a = 27;
						char b = 91;
						char c = 67;
						write(1,&a,1);
						write(1,&b,1);
						write(1,&c,1);
					}
				}
			}
		}
 	 }

  	// Add eol and null char at the end of string
  	line_buffer[line_length]=10;
  	line_length++;
  	line_buffer[line_length]=0;

  	tcsetattr(0, TCSANOW, &orig_attr);
  	return line_buffer;
}

