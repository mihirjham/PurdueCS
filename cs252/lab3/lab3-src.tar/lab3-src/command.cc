
/*
 * CS252: Shell project
 *
 * Template file.
 * You will need to add more code here to execute the command table.
 *
 * NOTE: You are responsible for fixing any bugs this code may have!
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include "command.h"
#include <regex.h>

SimpleCommand::SimpleCommand()
{
	// Creat available space for 5 arguments
	_numberOfAvailableArguments = 5;
	_numberOfArguments = 0;
	_arguments = (char **) malloc( _numberOfAvailableArguments * sizeof( char * ) );
}

void
SimpleCommand::insertArgument( char * argument )
{
	if ( _numberOfAvailableArguments == _numberOfArguments  + 1 ) {
		// Double the available space
		_numberOfAvailableArguments *= 2;
		_arguments = (char **) realloc( _arguments,
				  _numberOfAvailableArguments * sizeof( char * ) );
	}
	
	char *regularExpression = "^.*\\$\\{[^\\}][^\\}]*\\}.*$";
	regex_t re;
	int result = regcomp(&re, regularExpression, REG_EXTENDED|REG_NOSUB);
	if(result != 0)
	{
		fprintf(stderr, "Bad regular Expression \"%s\"\n", regularExpression);
		return;
	}
	regmatch_t match;
	result = regexec(&re, argument, 1, &match, 0);
	
	if(result == 0)
	{	
		char *arg = (char *)malloc(strlen(argument));
		char *newArg = (char *)malloc(strlen(argument));
		strcpy(arg, argument);

		int i = 0 ;
		int argumentIndex = 0;
		int varIndex = 0;
		int otherCharIndex = 0;
		
		newArg[0] = '\0';
		
		while(i < strlen(arg))
		{
			char *var = (char *)malloc(strlen(argument));
			char *otherChar = (char *)malloc(strlen(argument));

			while(*(arg+i) != '$')
			{
				*(otherChar+otherCharIndex) = *(arg+i);	
				i++;
				otherCharIndex++;
			}
			*(otherChar+otherCharIndex) = '\0';
			strcat(newArg, otherChar);	
			otherCharIndex = 0;
			free(otherChar);

			i=i+2;
			
			while(*(arg+i) != '}')
			{
				*(var + varIndex) = *(arg+i);
				i++;
				varIndex++;
			}
			*(var+varIndex) = '\0';
			strcat(newArg, getenv(var));
			argumentIndex = strlen(newArg)+1;
			varIndex = 0;
			free(var);
			i++;
			
		}
		
		strcpy(argument, newArg);
		free(arg);
		free(newArg);
	}
	regfree(&re);
	
	if(*argument == '~')
	{
		if(*(argument+1) == '/' || *(argument+1) == '\0')
		{
			char *remVar = (char *)malloc(1024);
			char *homeVar = (char *)malloc(1024);
			char *arg = (char *)malloc(1024);
		
			strcpy(arg, argument);

			if(homeVar && remVar && arg)
			{
				int i = 1;
				*remVar = '/';
				int remIndex = 1;
				while(*(arg+i) != '\0')
				{
					*(remVar+remIndex) = *(arg+i);
					remIndex++;
					i++;
				}
				*(remVar+remIndex) = '\0';
				strcpy(homeVar, getenv("HOME"));
				strcat(homeVar, remVar);
			
				if(homeVar)
				{
					strcpy(argument, homeVar);
				}
			}
			free(homeVar);	
			free(remVar);
			free(arg);
		}
		else
		{
			char *remVar = (char *)malloc(1024);
			char *homeVar = (char *)malloc(1024);
			char *arg = (char *)malloc(1024);
			
			strcpy(arg, argument);

			if(remVar && homeVar  && arg)
			{
				int i = 1;
				*remVar = '/';
				int remIndex = 1;
				while(*(arg+i) != '\0')
				{
					*(remVar+remIndex) = *(arg+i);
					remIndex++;
					i++;
				}
				*(remVar+remIndex) = '\0';
				strcpy(homeVar, "/homes");
				strcat(homeVar, remVar);

				if(homeVar)
				{
					strcpy(argument, homeVar);
				}
			}
			free(homeVar);
			free(remVar);
			free(arg);
		}
	}

	_arguments[ _numberOfArguments ] = argument;
	
	// Add NULL argument at the end
	_arguments[ _numberOfArguments + 1] = NULL;
	
	_numberOfArguments++;
}

Command::Command()
{
	// Create available space for one simple command
	_numberOfAvailableSimpleCommands = 1;
	_simpleCommands = (SimpleCommand **)
		malloc( _numberOfSimpleCommands * sizeof( SimpleCommand * ) );

	_numberOfSimpleCommands = 0;
	_outFile = 0;
	_inputFile = 0;
	_errFile = 0;
	_background = 0;
	_append = 0;
	_inFiles = 0;
	_outFiles = 0;

}

void
Command::insertSimpleCommand( SimpleCommand * simpleCommand )
{
	if ( _numberOfAvailableSimpleCommands == _numberOfSimpleCommands ) {
		_numberOfAvailableSimpleCommands *= 2;
		_simpleCommands = (SimpleCommand **) realloc( _simpleCommands,
			 _numberOfAvailableSimpleCommands * sizeof( SimpleCommand * ) );
	}
	
	_simpleCommands[ _numberOfSimpleCommands ] = simpleCommand;
	_numberOfSimpleCommands++;
}

void
Command:: clear()
{
	for ( int i = 0; i < _numberOfSimpleCommands; i++ ) {
		for ( int j = 0; j < _simpleCommands[ i ]->_numberOfArguments; j ++ ) {
			free ( _simpleCommands[ i ]->_arguments[ j ] );
		}
		
		free ( _simpleCommands[ i ]->_arguments );
		free ( _simpleCommands[ i ] );
	}

	if ( _outFile ) {
		free( _outFile );
	}

	if ( _inputFile ) {
		free( _inputFile );
	}
	
	//if ( _errFile ) {
	//	free( _errFile );
	//}

	_numberOfSimpleCommands = 0;
	_outFile = 0;
	_inputFile = 0;
	_errFile = 0;
	_background = 0;
	_append = 0;
	_inFiles = 0;
	_outFiles = 0;
}

void
Command::print()
{
	printf("\n\n");
	printf("              COMMAND TABLE                \n");
	printf("\n");
	printf("  #   Simple Commands\n");
	printf("  --- ----------------------------------------------------------\n");
	
	for ( int i = 0; i < _numberOfSimpleCommands; i++ ) {
		printf("  %-3d ", i );
		for ( int j = 0; j < _simpleCommands[i]->_numberOfArguments; j++ ) {
			printf("\"%s\" \t", _simpleCommands[i]->_arguments[ j ] );
		}
	}

	printf( "\n\n" );
	printf( "  Output       Input        Error        Background\n" );
	printf( "  ------------ ------------ ------------ ------------\n" );
	printf( "  %-12s %-12s %-12s %-12s\n", _outFile?_outFile:"default",
		_inputFile?_inputFile:"default", _errFile?_errFile:"default",
		_background?"YES":"NO");
	printf( "\n\n" );
	
}

void
Command::execute()
{
	// Don't do anything if there are no simple commands
	if ( _numberOfSimpleCommands == 0 ) {
		if(isatty(0))
		{
			prompt();
			return;
		}
	}
	// Print contents of Command data structure
	//print();
	
	// Add execution here
	// For every simple command fork a new process
	// Setup i/o redirection
	// and call exec
	
	//save in/out
	int tmpin = dup(0);
	int tmpout = dup(1);
	int tmperr = dup(2);

	//set the initial input
	int fdin;
	
	if(_inputFile)
	{
		fdin = open(_inputFile, O_RDONLY);
	}
	else
	{
		//Use default input
		fdin = dup(tmpin);
	}

	int ret;
	int fdout;
	int fderr;
	int i;
	for(i=0; i<_numberOfSimpleCommands; i++)
	{
		//redirect input
		dup2(fdin, 0);
		close(fdin);
		
		//set output
		if(i == _numberOfSimpleCommands-1)
		{
			//Last simple command
			if(!strcmp(_simpleCommands[i]->_arguments[0], "exit"))
				exit(0);
			
			if(!strcmp(_simpleCommands[i]->_arguments[0], "setenv"))
			{
				int error = setenv(_simpleCommands[i]->_arguments[1], _simpleCommands[i]->_arguments[2], 1);

				if(error)
				{
					perror("setenv");
				}
				
				clear();
				if(isatty(0))
					prompt();
				return;
			}
			
			if(!strcmp(_simpleCommands[i]->_arguments[0], "cd"))
			{
				if(_simpleCommands[i]->_arguments[1] == NULL)
				{
					int error = chdir(getenv("HOME"));
					
					if(error)
						perror("cd");
					
					clear();
					if(isatty(0))
						prompt();
					return;
				}
				
				int error = chdir(_simpleCommands[i]->_arguments[1]);
				
				if(error)
				{
					perror("cd");
				}

				clear();
				if(isatty(0))
					prompt();
				return;
			}
			/*if(!strcmp(_simpleCommands[i]->_arguments[0], "printenv"))
			{
				int j = 0;
				char *s = *environ;
				
				for(; s ; j++)
				{
					fprintf(stdout, "%s\n", s);
					s = *(environ + j);
				}

				clear();
				if(isatty(0))
					prompt();
				return;
			}*/
			
			if(!strcmp(_simpleCommands[i]->_arguments[0], "unsetenv"))
			{
				int error = unsetenv(_simpleCommands[i]->_arguments[1]);

				if(error)
					perror("unsetenv");

				clear();
				if(isatty(0))
					prompt();
				return;
			}
			if(_append && _outFile)
			{
				fdout = open(_outFile, O_CREAT|O_WRONLY|O_APPEND, 0664);	
				if(_errFile)
					fderr = dup(fdout);
				else
					fderr = dup(tmperr);
			}
			else if(_outFile)
			{
				fdout = open(_outFile, O_CREAT|O_WRONLY|O_TRUNC, 0664);
				if(_errFile)
					fderr = dup(fdout);
				else
					fderr = dup(tmperr);
			}
			else
			{
				//Use default output
				fdout = dup(tmpout);
			}
			
			if(_outFiles > 1)
			{
				perror("Ambiguous output redirect");
			}

			if(_inFiles > 1)
			{
				perror("Ambigious input redirect");
			}	
		}
		else
		{
			//Not last simple command
			//create a pipe

			int fdpipe[2];
			pipe(fdpipe);
			fdout = fdpipe[1];
			fdin = fdpipe[0];
		}
		
		//Redirect output
		dup2(fdout,1);
		close(fdout);
		dup2(fderr, 2);
		close(fderr);
		
		ret = fork();
		if(ret == 0)
		{
			//child
			execvp(_simpleCommands[i]->_arguments[0], _simpleCommands[i]->_arguments);
			perror("execvp");
			_exit(1);
		}
		else if(ret < 0)
		{
			perror("fork");
			return;
		}
	}
	
	dup2(tmpin,0);
	dup2(tmpout,1);
	dup2(tmperr, 2);
	close(tmpin);
	close(tmpout);
	close(tmperr);

	if(!_background)
	{
		waitpid(ret, NULL, 0);
	}

	// Clear to prepare for next command
	clear();
	
	// Print new prompt
	if(isatty(0)){
		prompt();
	}
}

// Shell implementation

void
Command::prompt()
{
	printf("myshell>");
	fflush(stdout);
}

Command Command::_currentCommand;
SimpleCommand * Command::_currentSimpleCommand;
int yyparse(void);

extern char **environ;

void handler(int s)
{
	if(SIGINT)
	{
		//fprintf(stderr, "\n");
	}
	
	if(SIGCHLD)
	{
		while(waitpid(-1,NULL,WNOHANG)>0);
	}
}
main()
{
	struct sigaction signalAction;
	
	signalAction.sa_handler = handler;
	sigemptyset(&signalAction.sa_mask);
	signalAction.sa_flags = SA_RESTART;

	int error = sigaction(SIGINT,&signalAction, NULL);
	if(error)
	{
		perror("sigaction");
		exit(-1);
	}
	
	error = sigaction(SIGCHLD, &signalAction, NULL);
	if(error)
	{
		perror("sigaction");
		exit(-1);
	}

//	while(1)
//	{
		if(isatty(0))
		{
			Command::_currentCommand.prompt();
		}
		yyparse();
//	}
}

