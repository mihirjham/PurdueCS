<script type="text/JavaScript">
var x = 1 + "a"
if(x){
	x = x + 1
}
</script>
