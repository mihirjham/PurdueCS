<script type="text/JavaScript">
var x = 1
var y = "a"
var z = "b"
while(x < 3){
	y = y + z + 1
	x = x + 1
	z = 2
}
</script>
