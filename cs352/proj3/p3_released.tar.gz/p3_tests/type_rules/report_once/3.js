<script type="text/JavaScript">
var x = 1
var y = "a"
while(x < 3){
	y = y + 1
	x = x + 1
	var y
}
</script>
