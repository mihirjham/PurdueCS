<script type="text/JavaScript">
var x = 2
y[2] = x
</script>
