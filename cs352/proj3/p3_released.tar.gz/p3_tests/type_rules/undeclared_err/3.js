<script type="text/JavaScript">
var x = 2
y.field = x
</script>
