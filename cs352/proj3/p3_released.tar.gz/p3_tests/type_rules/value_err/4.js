<script type="text/JavaScript">
var y = x[4]
</script>
