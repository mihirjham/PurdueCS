<script type="text/JavaScript">
var x = []
var z = 2
var y = x[z]
</script>
