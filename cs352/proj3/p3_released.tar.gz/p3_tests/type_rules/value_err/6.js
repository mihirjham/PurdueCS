<script type="text/JavaScript">
var x
var y = x.field
</script>
