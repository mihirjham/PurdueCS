<script type="text/JavaScript">
var x = 5 + "a"
var y = x + 2
var z = y + "b"
</script>
