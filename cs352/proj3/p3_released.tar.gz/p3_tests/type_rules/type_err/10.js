<script type="text/JavaScript">
var x = 1 + "a"
if(x && 1){
	x = x + 1
}
</script>
