<script type="text/JavaScript">
var x = []
x.field = 5
</script>
