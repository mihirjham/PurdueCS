<script type="text/JavaScript">
var x = []
var y = {}
y.field = x
</script>
