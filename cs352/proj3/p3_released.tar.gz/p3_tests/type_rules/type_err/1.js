<script type="text/JavaScript">
var x = "ab" > "cd"
</script>
