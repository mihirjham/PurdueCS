<script type="text/JavaScript">
var y = {}
y[5] = 7
</script>
