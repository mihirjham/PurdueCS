<script type="text/JavaScript">
var x = true == 1
</script>
