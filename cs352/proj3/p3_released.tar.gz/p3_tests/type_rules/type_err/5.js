<script type="text/JavaScript">
var x = []
var y = {}
x[1] = y
</script>
