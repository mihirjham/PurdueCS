<script type="text/JavaScript">
var x
y = 1 + "a" + x
</script>
