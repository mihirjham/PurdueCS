<script type="text/JavaScript">
var x
var y
var z = ((x + 2) * (1 + "a")) + y
</script>
