<script type="text/JavaScript">
var x
var y = 1 + "a" + x
</script>
