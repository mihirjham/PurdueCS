<script type="text/JavaScript">
var count = 0;
var oddeven = 0;
while(count < 5) {
	count = count + 1;
	if (oddeven == 0) {
		var a = "count" + count; oddeven = 1;
		document.write(a, "<br />");
	} else{
		var b = count + x; oddeven = 0;
		document.write(b, "<br />");
	}
}
</script>
