<script type="text/JavaScript">
var x = 2
var y = "3"
var z = x + y
document.write(z, "<br />")

if(z){
	document.write("wrong")
} else {
	document.write("still wrong")
}

while(z){
	document.write("not here")
}
z = 5
if(z > 2){
	while(z){
		document.write("hello bob", "<br />")
		z = z - 1
	}
}
var z
document.write(z, " is cool", "<br />")

var z = []
document.write(z[5+6-2], "<br />")
var z = {}
document.write(z.field, "<br />")

var z = []
z[50] = 2
z[56] = z[50] + 3*(2-1)

document.write(z[56], z[4], z[10], "<br />")

</script>
