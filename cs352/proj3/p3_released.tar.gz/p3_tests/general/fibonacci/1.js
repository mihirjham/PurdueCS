<script type="text/JavaScript">
var x = [0, 1]
var count = 2
while(count < 11){
	x[count] = x[count-1] + x[count-2]
	count = count + 1
}
document.write("fib(10) = ", x[10], "<br />");
</script>
