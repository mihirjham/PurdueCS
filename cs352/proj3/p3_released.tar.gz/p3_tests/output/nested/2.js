<script type="text/JavaScript">
if(1){
	var x = true
	if(x) {
		if("hello"){
			document.write("correct");
		}
	} else{
		document.write("wrong")
	}
}
</script>
