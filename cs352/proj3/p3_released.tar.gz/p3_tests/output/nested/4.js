<script type="text/JavaScript">
var x = 0
do{
	document.write(x)
	var y = 0
	do{
		document.write(y)
		y = y + 1
	}
	while(y < 2)
	x = x + 1
}
while (x < 2)
</script>
