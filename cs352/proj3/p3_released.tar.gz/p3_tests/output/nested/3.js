<script type="text/JavaScript">
var x = 0
while(x < 2){
	document.write(x)
	var y = 0
	while(y < 2){
		document.write(y)
		y = y + 1
	}
	x = x + 1
}
</script>
