<script type="text/JavaScript">
var x = 0
while (1){
	var y = 2
	if(y) {
		document.write("correct");
		break
	}
}
</script>
