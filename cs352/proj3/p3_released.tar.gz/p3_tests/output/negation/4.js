<script type="text/JavaScript">
if(!(1 - 1)){
	document.write("correct")
} else {
	document.write("wrong")
}
</script>
