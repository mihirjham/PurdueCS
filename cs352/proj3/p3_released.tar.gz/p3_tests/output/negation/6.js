<script type="text/JavaScript">
if(!(false)){
	document.write("correct")
} else {
	document.write("wrong")
}
</script>
