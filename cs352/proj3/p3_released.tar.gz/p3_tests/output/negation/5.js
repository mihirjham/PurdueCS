<script type="text/JavaScript">
if(!("")){
	document.write("correct")
} else {
	document.write("wrong")
}
</script>
