<script type="text/JavaScript">
var x = false
if(!x){
	document.write("correct")
} else {
	document.write("wrong")
}
</script>
