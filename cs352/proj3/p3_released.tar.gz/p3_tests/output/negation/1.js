<script type="text/JavaScript">
var x = ""
if(!x){
	document.write("correct")
} else {
	document.write("wrong")
}
</script>
