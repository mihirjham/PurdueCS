<script type="text/JavaScript">
var x = [1, 
	"abe", 
	"<br />"]
document.write(x[0], x[2], x[1])
</script>
