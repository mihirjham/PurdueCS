<script type="text/JavaScript">
var x = [1+2, "abe"+" lincoln", "<br />"]
document.write(x[0], x[2], x[1])
</script>
