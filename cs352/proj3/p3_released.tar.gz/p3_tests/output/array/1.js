<script type="text/JavaScript">
var x = []
x[1] = "a"
x[2] = 1
x[3] = "<br />"
document.write(x[1], x[3], x[2])
</script>
