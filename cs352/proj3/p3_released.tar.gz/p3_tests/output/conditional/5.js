<script type="text/JavaScript">
if(0){
	document.write("wrong");
} else if(2){
	document.write("correct");
}else {
	document.write("wrong");
}
</script>
