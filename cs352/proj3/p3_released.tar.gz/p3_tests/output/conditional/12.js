<script type="text/JavaScript">
if(false){
	document.write("wrong");
} else {
	document.write("correct");
}
</script>
