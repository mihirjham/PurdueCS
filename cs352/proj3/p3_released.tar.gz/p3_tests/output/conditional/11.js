<script type="text/JavaScript">
if(""){
	document.write("wrong");
} else {
	document.write("correct");
}
</script>
