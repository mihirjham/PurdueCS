<script type="text/JavaScript">
var x = true;
if(x){
	document.write("correct");
} else {
	document.write("wrong");
}
</script>
