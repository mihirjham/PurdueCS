<script type="text/JavaScript">
if("hello"){
	document.write("correct");
} else {
	document.write("hello")
}
</script>
