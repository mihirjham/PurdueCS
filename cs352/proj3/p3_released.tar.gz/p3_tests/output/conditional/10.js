<script type="text/JavaScript">
var x = "hello";
if(x){
	document.write("correct");
} else {
	document.write("wrong")
}
</script>
