<script type="text/JavaScript">
if(true){
	document.write("correct");
} else {
	document.write("wrong")
}
</script>
