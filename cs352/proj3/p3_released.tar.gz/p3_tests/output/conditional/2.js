<script type="text/JavaScript">
if(1){
	document.write("correct");
} else {
	document.write("wrong");
}
document.write("correct");
</script>
