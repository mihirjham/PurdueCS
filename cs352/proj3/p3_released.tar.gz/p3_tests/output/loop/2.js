<script type="text/JavaScript">
var x = 0
while(x < 2){
	document.write(x)
	break;
	x = x + 1
}
document.write(x)
</script>
