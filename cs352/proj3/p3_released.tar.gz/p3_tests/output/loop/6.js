<script type="text/JavaScript">
var x = 0
while(x){
	document.write(x)
	x = x + 1
}
document.write("correct")
</script>
