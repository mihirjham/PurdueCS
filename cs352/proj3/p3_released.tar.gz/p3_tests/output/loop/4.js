<script type="text/JavaScript">
var x = 0
do {
	document.write(x)
	x = x + 1
} 
while (x < 2)
</script>
