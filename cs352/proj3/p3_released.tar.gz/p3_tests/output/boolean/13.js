<script type="text/JavaScript">
if(1 || 0){
	document.write("correct");
} else {
	document.write("wrong")
}
</script>
