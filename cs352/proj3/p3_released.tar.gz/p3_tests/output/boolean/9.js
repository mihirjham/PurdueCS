<script type="text/JavaScript">
if(true == true){
	document.write("correct");
} else {
	document.write("wrong");
}
</script>
