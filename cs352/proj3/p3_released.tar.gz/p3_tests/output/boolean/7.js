<script type="text/JavaScript">
if("a" != "b"){
	document.write("correct");
} else {
	document.write("wrong")
}
</script>
