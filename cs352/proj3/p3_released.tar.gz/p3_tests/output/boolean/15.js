<script type="text/JavaScript">
if(2 > 2){
	document.write("wrong");
} else {
	document.write("correct");
}
</script>
