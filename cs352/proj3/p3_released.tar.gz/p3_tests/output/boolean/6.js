<script type="text/JavaScript">
if(3 != 2){
	document.write("correct");
}else {
	document.write("wrong")
}
</script>
