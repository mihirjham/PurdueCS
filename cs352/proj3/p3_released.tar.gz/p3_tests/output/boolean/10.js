<script type="text/JavaScript">
if(true != false){
	document.write("correct");
} else {
	document.write("wrong")
}
</script>
