<script type="text/JavaScript">
if(2 <= 2){
	document.write("correct");
} else {
 	document.write("wrong");	
 }
</script>
