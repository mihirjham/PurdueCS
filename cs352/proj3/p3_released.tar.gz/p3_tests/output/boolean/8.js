<script type="text/JavaScript">
if("a" == "a"){
	document.write("correct");
} else {
	document.write("wrong")
}
</script>
