<script type="text/JavaScript">
do {
	var a = 1;
} 
while(0)
</script>
