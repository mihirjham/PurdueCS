<script type="text/JavaScript">
while(0){
	var a = 1;
	a = 5;
	a = 6;
	while (0){
		var x = "nested";
		while(""){
			var z = "more nesting"
		}
	}
}
</script>
