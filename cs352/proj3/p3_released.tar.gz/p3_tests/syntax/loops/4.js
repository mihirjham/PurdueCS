<script type="text/JavaScript">
while(0){

} 
while (0){

}
</script>
