<script type="text/JavaScript">
while(0){
	var a = 1;
}
</script>
