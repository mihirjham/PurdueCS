<script type="text/JavaScript">
do {
	
} 
while(0)

do {


}
while (0)
</script>
