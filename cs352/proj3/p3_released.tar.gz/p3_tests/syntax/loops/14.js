<script type="text/JavaScript">
do{
	var a = 1;
	a = 5;
	a = 6;
	do{
		var x = "nested";
		do{
			var z = "more nesting"
		}
		while("")
	}
	while(0)
}
while(0)
</script>
