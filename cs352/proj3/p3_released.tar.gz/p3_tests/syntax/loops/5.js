<script type="text/JavaScript">
while(0){
	var a = 1;
	a = 5;
	a = 6;
} 
while (0){
	var c;
	c = 8 * 9;
	var b = 2;
	b = 6 + 2;
	b = b + b;
}
</script>
