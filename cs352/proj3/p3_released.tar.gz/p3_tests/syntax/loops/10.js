<script type="text/JavaScript">
do {
	var a = 1;
	a = 5;
	a = 6;
} 
while(0)
</script>
