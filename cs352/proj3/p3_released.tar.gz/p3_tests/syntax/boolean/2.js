<script type="text/JavaScript">
if(1 && 2){
	var z;
}
</script>
