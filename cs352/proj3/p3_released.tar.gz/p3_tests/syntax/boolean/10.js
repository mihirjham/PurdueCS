<script type="text/JavaScript">
var foo = 2;
if(1 != 2 && "hello" || foo){
	var x;
}
</script>
