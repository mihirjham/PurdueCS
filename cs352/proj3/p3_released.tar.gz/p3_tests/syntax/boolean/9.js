<script type="text/JavaScript">
if(1 != 2 && "hello"){
	var x;
}
</script>
