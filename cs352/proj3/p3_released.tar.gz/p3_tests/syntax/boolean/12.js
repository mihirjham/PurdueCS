<script type="text/JavaScript">
if(false){
	var x;
}
</script>
