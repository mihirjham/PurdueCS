<script type="text/JavaScript">
if(true){
	var x;
}
</script>
