<script type="text/JavaScript">
var x = [1+3, "foo" + " bar"]
</script>
