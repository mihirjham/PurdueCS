<script type="text/JavaScript">
var x = [
	2, 	"abe"
	]
</script>
