<script type="text/JavaScript">
var x = []
x[5] = "a"
</script>
