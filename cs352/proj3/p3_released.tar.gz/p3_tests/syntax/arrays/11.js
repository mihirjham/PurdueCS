<script type="text/JavaScript">
var x = []
x[5+10 / 2 * 3] = 10 
</script>
