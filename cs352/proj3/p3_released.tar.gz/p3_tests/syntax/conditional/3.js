<script type="text/JavaScript">
if(1){
	var a = 1;
	a = 5;
	a = 6;
}
</script>
