<script type="text/JavaScript">
if(1){

} else {
	var b = 2;
	b = 6 + 2;
	b = b + b;
}
</script>
