<script type="text/JavaScript">
if(1){
	var a = 1;
	a = 5;
	a = 6;
	if (6){
		var x = "nested";
	}
} else {
	var b = 2;
	b = 6 + 2;
	b = b + b;
}
</script>
