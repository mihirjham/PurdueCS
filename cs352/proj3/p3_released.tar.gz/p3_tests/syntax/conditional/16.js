<script type="text/JavaScript">
if(1){
	var a = 1;
	a = 5;
	a = 6;
} else if (2){
	var c;
	c = 8 * 9;
} else if(5){
	var d;
	d = 5;
	d = 9 / 3;
} else {
	var b = 2;
	b = 6 + 2;
	b = b + b;
}
</script>
