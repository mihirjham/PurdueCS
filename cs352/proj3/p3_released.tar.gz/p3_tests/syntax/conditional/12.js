<script type="text/JavaScript">
if(1){

} else if (2){

} else {

}
</script>
