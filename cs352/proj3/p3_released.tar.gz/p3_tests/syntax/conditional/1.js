<script type="text/JavaScript">
if(1){

}
</script>
