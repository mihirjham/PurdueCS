<script type="text/JavaScript">
while(1){
	var x = 2
</script>
