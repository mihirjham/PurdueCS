<script type="text/JavaScript">
var x = [
	"abe",
	]
</script>
