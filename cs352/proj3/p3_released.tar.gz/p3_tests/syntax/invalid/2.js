<script type="text/JavaScript">
if(1){
	var x = 2;

</script>
