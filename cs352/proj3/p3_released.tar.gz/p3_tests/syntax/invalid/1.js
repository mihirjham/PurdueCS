<script type="text/JavaScript">
if(1)
	var a = 3;
}
</script>
