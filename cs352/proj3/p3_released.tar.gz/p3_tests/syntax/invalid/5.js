<script type="text/JavaScript">
while(1{
	var a = 2;
}
</script>
