<script type="text/JavaScript">
while(1)
	var x;
}
</script>
