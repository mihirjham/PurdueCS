int default_hash(int id);
