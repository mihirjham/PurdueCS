int main();
int validate(char *);
int check(char *, char *);
int badguy(char *);
