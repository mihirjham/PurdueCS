void init();
void print_secret();

extern char *name;
