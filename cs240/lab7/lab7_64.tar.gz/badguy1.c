#include <stdio.h>
#include "callstack.h"

int badguy(char *password) {
    /* FILL THIS IN */
}
