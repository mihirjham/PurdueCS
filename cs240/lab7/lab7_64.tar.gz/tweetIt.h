void tweetIt(char msg[], int len);
