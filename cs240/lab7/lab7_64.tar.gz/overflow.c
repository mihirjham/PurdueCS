#include<stdlib.h>
#include"vulnerable.h"

void init() {
  /* FILL THIS IN */
}

